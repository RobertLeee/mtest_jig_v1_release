# coding: utf-8
# !/usr/bin/python

import keyboard
import click
import sys
import time
import datetime
import pexpect, os
import redpitaya_scpi
from statemachine import StateMachine, State

# @click.command()
# @click.option('--addr', default='192.168.0.77', help='IP address.')
# @click.option('--port', default='22', prompt='port', help='press "ctrl+c" to stop')

def redpitaya_scpi_enable():
    process = pexpect.spawn("sshpass -p root ssh -p 22 root@192.168.0.77")
    process.timeout = 5
    process.expect(":~#")
    process.sendline("systemctl start redpitaya_scpi &")
    process.expect(":~#")
    process.sendline("exit")

# timestamp
def current_time():
    current_time_ms = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
    return current_time_ms


# led control
def led_blink(led_num, period_ms, cycle_num, final_state):
    for i in range(cycle_num):
        time.sleep(period_ms / 2000)
        rp_s.tx_txt('DIG:PIN LED' + str(led_num) + ',' + str(1))
        time.sleep(period_ms / 2000)
        rp_s.tx_txt('DIG:PIN LED' + str(led_num) + ',' + str(0))
    rp_s.tx_txt('DIG:PIN LED' + str(led_num) + ',' + str(final_state))


# initial fan control
def set_fan():
    print(current_time(), ": set_fan")
    rp_s.tx_txt('DIG:PIN:DIR OUT,DIO0_P')
    rp_s.tx_txt('DIG:PIN DIO0_P,0')


# initial peripheral control
def set_peripheral():
    print(current_time(), ": set_peripheral")
    rp_s.tx_txt('DIG:PIN:DIR OUT,DIO0_P')
    rp_s.tx_txt('DIG:PIN DIO0_P,0')
    rp_s.tx_txt('DIG:PIN:DIR OUT,DIO0_N')
    rp_s.tx_txt('DIG:PIN DIO0_N,0')


# clear control status
def clear_dio0_p_dio0_n():
    print(current_time(), ": clear dio0-p and dio0-n")
    rp_s.tx_txt('DIG:PIN:DIR OUT,DIO0_P')
    rp_s.tx_txt('DIG:PIN DIO0_P,1')
    rp_s.tx_txt('DIG:PIN:DIR OUT,DIO0_N')
    rp_s.tx_txt('DIG:PIN DIO0_N,1')


# read from analog input
def read_ain(ain_num):
    rp_s.tx_txt('ANALOG:PIN? AIN' + str(ain_num))
    ain_read = float("{:.3f}".format(float(rp_s.rx_txt()) * 1.963))
    return ain_read


# initial test JIG
def Initial_test_JIG():
    print(current_time(), ": Initial_test_JIG")
    AIN = [0.000] * 4
    clear_dio0_p_dio0_n()
    try:
        AIN[0] = read_ain(0)
        AIN[1] = read_ain(1)
        while AIN[0] > 0.200 or AIN[1] > 0.200:
            for i in range(2):
                AIN[i] = read_ain(i)
                print("Measured voltage on AI[" + str(i) + "] = " + str(AIN[i]) + "V")
                led_blink(i, 300, 2, 0)
        else:
            for i in range(4):
                AIN[i] = read_ain(i)
                print("Measured voltage on AI[" + str(i) + "] = " + str(AIN[i]) + "V")
                led_blink(i, 300, 2, 0)
            led_blink(2, 300, 2, 1)
    except KeyboardInterrupt:
        clear_dio0_p_dio0_n()


# fan test procedure
def fan_test():
    try:
        set_fan()
        led_blink(0, 300, 2, 1)
        fan_test_dur = 25.000
        start = time.time()
        elpd_time = time.time() - start
        AIN0_read = read_ain(0)
        while AIN0_read < 0.200:
            AIN0_read = read_ain(0)
            print("Fan voltage on AI[" + str(0) + "] = " + str(AIN0_read) + "V" + ", " + "Time Elapsed = " + str(
                elpd_time), end='\r')
            led_blink(2, 300, 2, 1)
            elpd_time = time.time() - start
        else:
            print("----Fan voltage is detected on AI0----")
            for i in range(4):
                value = read_ain(i)
                print("Measured voltage on AI[" + str(i) + "] = " + str(value) + "V")
                led_blink(2, 500, 2, 1)
            time.sleep(4.0)
            led_blink(0, 300, 3, 0)
    except KeyboardInterrupt:
        clear_dio0_p_dio0_n()


# peripheral test procedure
def peripheral_test():
    try:
        set_peripheral()
        led_blink(1, 300, 2, 1)
        peripheral_test_dur = 25.000
        start = time.time()
        elpd_time = time.time() - start
        AIN1_read = read_ain(1)
        while AIN1_read < 0.200:
            AIN1_read = read_ain(1)
            print("peripheral voltage on AI[" + str(1) + "] = " + str(AIN1_read) + "V" + ", " + "Time Elapsed = " + str(
                elpd_time), end='\r')
            led_blink(2, 300, 2, 1)
            elpd_time = time.time() - start
        else:
            print("----peripheral voltage is detected on AI1----")
            for i in range(4):
                value = read_ain(i)
                print("Measured voltage on AI[" + str(i) + "] = " + str(value) + "V")
                led_blink(2, 300, 2, 1)
            time.sleep(7.0)
            led_blink(1, 300, 3, 0)
            clear_dio0_p_dio0_n()
    except KeyboardInterrupt:
        clear_dio0_p_dio0_n()


# standby procedure
def standby():
    AIN = [0.000] * 4
    standby_delay = 25.000
    start = time.time()
    elpd_time = time.time() - start
    try:
        for i in range(4):
            AIN[i] = read_ain(i)
            led_blink(i, 300, 2, 0)
        while AIN[0] > 0.200 or AIN[1] > 0.200 or AIN[2] < 3.13 or AIN[3] < 4.65 or elpd_time < standby_delay:
            if elpd_time > standby_delay / 3:
                clear_dio0_p_dio0_n()
            print("AI[0] = " + str(AIN[0]) + "V" + ", " + "AI[1] = " + str(AIN[1]) + "V" + ", " + "AI[2] = " + str(
                AIN[2]) + "V" + ", " + "AI[3] = " + str(AIN[3]) + "V" + ", " + "Time Elapsed = " + str(elpd_time),
                  end='\r')
            for i in range(4):
                AIN[i] = read_ain(i)
            elpd_time = time.time() - start
        else:
            print("AI[0] = " + str(AIN[0]) + "V" + ", " + "AI[1] = " + str(AIN[1]) + "V" + ", " + "AI[2] = " + str(
                AIN[2]) + "V" + ", " + "AI[3] = " + str(AIN[3]) + "V" + ", " + "Time Elapsed = " + str(elpd_time))
    except KeyboardInterrupt:
        clear_dio0_p_dio0_n()


# config FSM
class MTest_FSM(StateMachine):
    initial = State('Initial', initial=True)
    fan_test = State('Fan Test')
    peripheral_test = State('Peripheral Test')
    standby = State('Standby')

    cycle = initial.to(fan_test) | fan_test.to(peripheral_test) | peripheral_test.to(standby) | standby.to(initial)

    def on_enter_initial(self):
        print("Initial start.......")
        Initial_test_JIG()
        print("test JIG is ready.......")

    def on_enter_fan_test(self):
        print("fan_test start.......")
        fan_test()

    def on_enter_peripheral_test(self):
        print("peripheral_test start.......")
        peripheral_test()

    def on_enter_standby(self):
        print("standby.......")
        standby()


def main():

    mtest_fsm = MTest_FSM()
    try:
        while True:
            mtest_fsm.cycle()

    # press 'ctrl+c' to stop
    except KeyboardInterrupt:
        clear_dio0_p_dio0_n()


if __name__ == "__main__":
    #scpi enable
    redpitaya_scpi_enable()
    # call Red_Pitaya function
    rp_s = redpitaya_scpi .scpi('192.168.0.77')
    # initial
    Initial_test_JIG()
    # run FSM
    main()
